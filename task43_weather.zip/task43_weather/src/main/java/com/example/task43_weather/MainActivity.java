package com.example.task43_weather;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;

public class MainActivity extends AppCompatActivity {

    final String ATTR_NAME_TV = "TextView";
    final String ATTR_NAME_PB = "ProgressBar";
    final String ATTR_NAME_LL = "LinearLayout ";
    final String ATTR_NAME_IV = "ImageView";


    ListView lvList;

    public int getRandomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        int[] percents = {0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        int[] temperature = {-10, -6, -2, 0, 2, 6, 10, };
        String[] days = {"1.01", "2.01", "3.01", "4.01", "5.01", "6.01", "7.01", "8.01", "9.01", "10.01", "11.01", "12.01" };

        ArrayList<Map<String, Object>> data = new ArrayList<Map<String, Object>>(percents.length);
        Map<String, Object> m;

        int j = 0;
        for (int i = 0; i < percents.length; i++) {
            int randomTemperature = getRandomNumber(0,6);
            int randomHumidity = getRandomNumber(0,9);

            m = new HashMap<String, Object>();
            m.put(ATTR_NAME_TV, days[j] + " Temperature: " + temperature[randomTemperature] + ". Humidity:  " + percents[randomHumidity] + "%");
            m.put(ATTR_NAME_PB, percents[randomHumidity]);
            m.put(ATTR_NAME_LL, temperature[randomTemperature]);
            m.put(ATTR_NAME_IV, temperature[randomTemperature]);
            data.add(m);

            j++;
        }

        String[] from = { ATTR_NAME_TV, ATTR_NAME_PB, ATTR_NAME_LL, ATTR_NAME_IV };
        int[] to = { R.id.tvInput, R.id.pbInput, R.id.llInput, R.id.ivItem };

        SimpleAdapter sAdapter = new SimpleAdapter(this, data, R.layout.item, from, to);
        sAdapter.setViewBinder(new MyViewBinder());

        lvList = (ListView) findViewById(R.id.lvList);
        lvList.setAdapter(sAdapter);
    }

    class MyViewBinder implements SimpleAdapter.ViewBinder {

        int blue = getResources().getColor(R.color.Blue);
        int green = getResources().getColor(R.color.Green);
        int yellow = getResources().getColor(R.color.Yellow);
        int red = getResources().getColor(R.color.Red);

        @Override
        public boolean setViewValue(View view, Object data, String textRepresentation) {

            int i = 0;
            switch (view.getId()) {
                // ImageView
                case R.id.ivItem:
                    i = ((Integer) data).intValue();
                    if (i == 0) ((ImageView)view).setImageResource(R.drawable.ic_baseline_cloud_queue_24); else
                    if (i > 0) ((ImageView)view).setImageResource(R.drawable.ic_baseline_wb_sunny_24); else
                    if (i < 0) ((ImageView)view).setImageResource(R.drawable.ic_baseline_mood_bad_24);
                    return true;
                // LinearLayout
                case R.id.llInput:
                    i = ((Integer) data).intValue();
                    if (i == 0) view.setBackgroundColor(yellow); else
                    if (i > 0) view.setBackgroundColor(red); else
                    if (i < 0) view.setBackgroundColor(blue); else
                        view.setBackgroundColor(green);
                    return true;
//                 ProgressBar
                case R.id.pbInput:
                    i = ((Integer) data).intValue();
                    ((ProgressBar)view).setProgress(i);
                    return true;
            }
            return false;
        }
    }
}
