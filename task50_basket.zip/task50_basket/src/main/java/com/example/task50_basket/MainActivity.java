package com.example.task50_basket;


import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;



public class MainActivity extends AppCompatActivity {

    final String TAG = "dbLogs";

    final String ATTR_NAME_TEXT = "TextView";
    final String ATTR_NAME_IMAGE = "ImageView";

    private static final int DELETE_ID = 1;
    private static final int ADD_ID = 2;

    ListView lvList;
    SimpleAdapter sAdapter;
    public ArrayList<Map<String, Object>> data;
    Map<String, Object> map;
    TextView outputBasket;


    //zadeklarowanie listy produktów do wyboru
    String[] items = {
            "Jabłko", "Awokado","Banan", "Cytryna",
            "Czosnek", "Brokuł", "Kapusta", "Ogórek",
            "Pomidor", "Truskawki", "Winogrono", "Ziemniak" };

    //zadeklarowanie listy produktów dodanych do koszyka
    List<String> basket = new ArrayList<String>();

    //zadeklarowanie listy id grafik produktow
    ArrayList<Integer> images = new ArrayList<Integer>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //wczytanie id wszystkich grafik do listy images
        images.add(R.drawable.jablko);
        images.add(R.drawable.awokado);
        images.add(R.drawable.banany);
        images.add(R.drawable.cytryna);
        images.add(R.drawable.czosnek);
        images.add(R.drawable.brokul);
        images.add(R.drawable.kapusta);
        images.add(R.drawable.ogorek);
        images.add(R.drawable.pomidor);
        images.add(R.drawable.truskawki);
        images.add(R.drawable.winogrono);
        images.add(R.drawable.ziemniaki);

        //TextView do wyswietlania zawartości koszyka
        outputBasket = findViewById(R.id.outputBasket);

        data = new ArrayList<Map<String, Object>>();
        for (int i = 1; i <= items.length; i++) {
            Log.d(TAG,"pętla dodającac itemy do listy - " + i);
            map = new HashMap<String, Object>();
            map.put(ATTR_NAME_TEXT, items[i-1]);
            map.put(ATTR_NAME_IMAGE, images.get(i - 1));
            data.add(map);
        }

        String[] from = { ATTR_NAME_IMAGE, ATTR_NAME_TEXT };
        int[] to = { R.id.ivImage, R.id.tvText };
        sAdapter = new SimpleAdapter(this, data, R.layout.item, from, to);

        lvList = (ListView) findViewById(R.id.lvList);
        lvList.setAdapter(sAdapter);
        registerForContextMenu(lvList);


    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0, DELETE_ID, 0, "Delete item");
        menu.add(0, ADD_ID, 0, "Add item to basket");
        Log.d(TAG, "onCreateContextMenu called");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {


        if (item.getItemId() == DELETE_ID) {
            outputBasket.setText("");
            AdapterContextMenuInfo acmi = (AdapterContextMenuInfo) item.getMenuInfo();
            TextView tvText = findViewById(R.id.tvText);
            String text = (String) data.get(acmi.position).get(ATTR_NAME_TEXT);
            Log.d(TAG, "do usuniecia: " + text);
            try {
                basket.remove(text);
            } catch (Exception exception) {
                Log.d(TAG, exception.getMessage());
            }
            try {
                for (int j = 0; j <= basket.size(); j++) {
                    outputBasket.append(" - " + basket.get(j) + "\n");
                }
            } catch (Exception exception) {
                Log.d(TAG, exception.getMessage());
            }
            return true;
        }


        else if (item.getItemId() == ADD_ID) {
            outputBasket.setText("");
            AdapterContextMenuInfo acmi = (AdapterContextMenuInfo) item.getMenuInfo();
            TextView tvText = findViewById(R.id.tvText);
            String text = (String) data.get(acmi.position).get(ATTR_NAME_TEXT);
            basket.add(text);
            try {
                for (int j = 0; j <= basket.size(); j++) {
                    outputBasket.append(" - " + basket.get(j) + "\n");
                }
            } catch (Exception exception) {
                Log.d(TAG, exception.getMessage());
            }

        }


        return super.onContextItemSelected(item);
    }



}